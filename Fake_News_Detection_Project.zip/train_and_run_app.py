
# train_and_run_app.py

# Step 1: Import libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.metrics import accuracy_score
import joblib

# Step 2: Load and prepare dataset
fake = pd.read_csv("Augmented_Fake.csv")
true = pd.read_csv("Augmented_True.csv")

fake["label"] = 0
true["label"] = 1

data = pd.concat([fake, true], ignore_index=True)
data = data.sample(frac=1, random_state=42).reset_index(drop=True)
data["content"] = data["title"] + " " + data["text"]

# Step 3: Split data
X_train, X_test, y_train, y_test = train_test_split(data["content"], data["label"], test_size=0.25, random_state=42)

# Step 4: TF-IDF vectorization
vectorizer = TfidfVectorizer(stop_words="english", max_df=0.7)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Step 5: Model training
model = PassiveAggressiveClassifier(max_iter=1000)
model.fit(X_train_vec, y_train)

# Step 6: Save model and vectorizer
joblib.dump(model, "pac_model.pkl")
joblib.dump(vectorizer, "vectorizer.pkl")

# Step 7: Evaluate
y_pred = model.predict(X_test_vec)
acc = accuracy_score(y_test, y_pred)
print(f"Model trained with accuracy: {acc:.4f}")


import streamlit as st
import pandas as pd
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import PassiveAggressiveClassifier

# Load trained vectorizer and model (replace with actual file paths if needed)
@st.cache_resource
def load_model():
    vectorizer = joblib.load("vectorizer.pkl")
    model = joblib.load("pac_model.pkl")
    return vectorizer, model

st.title("📰 Fake News Detection App")
st.write("Enter a news article or headline below to check if it's FAKE or REAL.")

# Input
news_input = st.text_area("Enter news content here:", height=200)

# Load model
vectorizer, model = load_model()

# Predict
if st.button("Classify"):
    if news_input.strip() == "":
        st.warning("Please enter some text to classify.")
    else:
        vec_input = vectorizer.transform([news_input])
        prediction = model.predict(vec_input)[0]
        result = "REAL 🟢" if prediction == 1 else "FAKE 🔴"
        st.success(f"Prediction: {result}")
